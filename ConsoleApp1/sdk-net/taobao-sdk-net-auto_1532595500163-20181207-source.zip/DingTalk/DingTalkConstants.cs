﻿using System;
namespace Top.Api.DingTalk
{
    public sealed class DingTalkConstants
    {
        public const string CALL_TYPE_TOP = "top";
        public const string CALL_TYPE_OAPI = "oapi";

        public const string ACCESS_TOKEN = "access_token";
    }
}
